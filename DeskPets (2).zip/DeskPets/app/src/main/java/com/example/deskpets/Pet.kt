package com.example.deskpets

import android.view.GestureDetector
import android.view.VelocityTracker
import android.view.WindowManager

enum class State { IDLE, WALK, SLEEP, EAT, DRAG, FALL }

/** Один улюбленець: його вікно-оверлей і фізичний стан. */
class Pet(
    val type: Int,
    val view: PetView,
    val lp: WindowManager.LayoutParams
) {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f
    var state = State.IDLE
    var lastState = State.FALL
    var dir = 1
    var timer = 1f
    var t = 0f
    var walkPhase = 0f
    var blinkT = 2f
    var bubble: String? = null
    var bubbleT = 0f
    var fullness = 0f

    var grabDx = 0f
    var grabDy = 0f
    var downX = 0f
    var downY = 0f
    var dragging = false
    var tracker: VelocityTracker? = null
    lateinit var detector: GestureDetector

    val cx: Float get() = x + lp.width / 2f
}
