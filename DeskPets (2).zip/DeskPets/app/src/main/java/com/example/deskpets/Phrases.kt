package com.example.deskpets

object Phrases {
    const val TYPE_COUNT = 9
    val typeNames = listOf("Заєць", "Краб", "Робот", "Кіт", "Gemini", "Grok", "DeepSeek", "ChatGPT", "Kimi")
    val food = listOf("🥕", "🍤", "🔋", "🐟", "⭐", "🚀", "🦐", "💬", "🌙")

    private val common = listOf(
        "Привіт!", "Як справи?", "Я просто гуляю", "Що там у чаті?",
        "Хочу їсти...", "Тапни двічі — і я поїм!", "Тут так затишно",
        "Спробуй мене кинути :)", "Не дивись так"
    )
    private val special = listOf(
        listOf("Хрум-хрум", "Де моя морква?"),
        listOf("Боком-боком", "Клац-клац"),
        listOf("> npm run build", "01001000 01101001", "Усі системи в нормі"),
        listOf("Няв", "Мур-мур", "Це мій екран"),
        listOf("Давай розберемось", "Ой, я тут зірка"),
        listOf("Скажу як є", "Я дотепний. Майже."),
        listOf("Дай подумати...", "Пірнаю глибоко"),
        listOf("Чим можу допомогти?", "Звісно! Ось що я думаю..."),
        listOf("Привіт! Я Kimi", "Місяць сьогодні гарний")
    )

    fun chat(type: Int): String =
        (common + special[type.coerceIn(0, special.size - 1)]).random()

    val yum = listOf("Ням-ням!", "Смакота!", "Ще!", "Дякую!", "Мммм!")
    val full = listOf("Я більше не можу!", "Лопну!", "Уфф, наївся")
    val scared = listOf("Аааа!", "Постав мене!", "Куди?!", "Вау-у!")
    val tap = listOf("Привіт!", "Ой!", "Га?", "Що?", "Лоскотно!")
    val ouch = listOf("Ай!", "Бдзинь!", "Уф...", "Приземлився")
    val wake = listOf("Я не сплю!", "Га?", "Ще п'ять хвилин...")
}
