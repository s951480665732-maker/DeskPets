package com.example.deskpets

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/** Параметри анімації, які сервіс виставляє кожен кадр. */
class AnimState {
    var walk = -1f          // фаза ходьби 0..1, -1 = стоїть
    var sleeping = false
    var eating = 0f         // 0..1 відкритість рота
    var scared = false      // його несуть у руці
    var dir = 1
    var eyeOpen = 1f
    var t = 0f
}

/**
 * Малює улюбленців у логічній сітці 48x48. У "піксельному" режимі ця сітка
 * малюється в маленьку картинку без згладжування і розтягується — виходить піксель-арт.
 */
object PetArt {
    const val RABBIT = 0
    const val CRAB = 1
    const val ROBOT = 2
    const val CAT = 3
    const val GEMINI = 4
    const val GROK = 5
    const val DEEPSEEK = 6
    const val CHATGPT = 7
    const val KIMI = 8

    /** Іконки ШІ-застосунків — це картинки, а не намальовані фігури */
    fun isLogo(type: Int): Boolean = type >= GEMINI

    fun spriteRes(type: Int): Int = when (type) {
        GEMINI -> R.drawable.pet_gemini
        GROK -> R.drawable.pet_grok
        DEEPSEEK -> R.drawable.pet_deepseek
        CHATGPT -> R.drawable.pet_chatgpt
        KIMI -> R.drawable.pet_kimi
        else -> 0
    }

    private const val TWO_PI = 6.2831855f
    private val DARK = 0xFF3A2A1E.toInt()
    private val PINK = 0xFFFF9EB0.toInt()
    private val path = Path()
    private val spritePaint = Paint()
    private val dstRect = RectF()

    fun draw(c: Canvas, type: Int, a: AnimState, p: Paint, sprite: Bitmap? = null) {
        c.save()
        if (a.dir < 0 && type != CRAB && !isLogo(type)) {
            c.translate(48f, 0f)
            c.scale(-1f, 1f)
        }
        if (a.sleeping) {
            c.scale(1.08f, 0.82f, 24f, 46f)
        } else if (a.scared) {
            c.rotate(sin(a.t * 22f) * 9f, 24f, 8f)
        }
        // тінь
        p.style = Paint.Style.FILL
        p.color = 0x44000000
        c.drawOval(6f, 44f, 42f, 47.5f, p)

        when (type) {
            RABBIT -> rabbit(c, p, a)
            CRAB -> crab(c, p, a)
            ROBOT -> robot(c, p, a)
            CAT -> cat(c, p, a)
            else -> if (sprite != null) logo(c, p, a, sprite)
        }
        c.restore()
    }

    // ---------- допоміжні функції ----------
    private fun ov(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, fill: Int) {
        p.style = Paint.Style.FILL; p.color = fill
        c.drawOval(l, t, r, b, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f; p.color = DARK
        c.drawOval(l, t, r, b, p)
        p.style = Paint.Style.FILL
    }

    private fun fo(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, fill: Int) {
        p.style = Paint.Style.FILL; p.color = fill
        c.drawOval(l, t, r, b, p)
    }

    private fun rr(c: Canvas, p: Paint, l: Float, t: Float, r: Float, b: Float, rad: Float, fill: Int, outline: Boolean = true) {
        p.style = Paint.Style.FILL; p.color = fill
        c.drawRoundRect(l, t, r, b, rad, rad, p)
        if (outline) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f; p.color = DARK
            c.drawRoundRect(l, t, r, b, rad, rad, p)
            p.style = Paint.Style.FILL
        }
    }

    private fun dot(c: Canvas, p: Paint, x: Float, y: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(x, y, r, p)
    }

    private fun line(c: Canvas, p: Paint, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = w; p.color = color
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(x1, y1, x2, y2, p)
        p.style = Paint.Style.FILL
    }

    private fun tri(c: Canvas, p: Paint, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, fill: Int, outline: Boolean) {
        path.reset()
        path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        p.style = Paint.Style.FILL; p.color = fill
        c.drawPath(path, p)
        if (outline) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f; p.color = DARK
            p.strokeJoin = Paint.Join.ROUND
            c.drawPath(path, p)
            p.style = Paint.Style.FILL
        }
    }

    private fun eye(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, open: Float) {
        if (open < 0.3f) {
            line(c, p, cx - r, cy, cx + r, cy, 1.3f, DARK)
        } else {
            p.style = Paint.Style.FILL; p.color = DARK
            c.drawOval(cx - r, cy - r * open, cx + r, cy + r * open, p)
        }
    }

    // ---------- іконки-улюбленці (Gemini, Grok, DeepSeek, ChatGPT, Kimi) ----------
    private fun logo(c: Canvas, p: Paint, a: AnimState, bmp: Bitmap) {
        val s = if (a.walk >= 0f) sin(a.walk * TWO_PI) else 0f
        val hop = if (a.walk >= 0f) -abs(s) * 3f else 0f
        val bob = if (a.eating > 0.1f) sin(a.t * 14f) * 0.06f else 0f
        val bottom = 41f + hop
        val leg = 0xFFD9DCE8.toInt()
        // ніжки (піднімаються по черзі під час ходьби)
        rr(c, p, 15f, 39f - max(0f, s) * 3f, 21f, 46f - max(0f, s) * 3f, 2.5f, leg)
        rr(c, p, 27f, 39f - max(0f, -s) * 3f, 33f, 46f - max(0f, -s) * 3f, 2.5f, leg)
        c.save()
        if (a.walk >= 0f) c.rotate(s * 5f, 24f, bottom)   // перевалочка
        val w = 36f * (1f - bob)
        val h = 36f * (1f + bob)
        dstRect.set(24f - w / 2f, bottom - h, 24f + w / 2f, bottom)
        spritePaint.isFilterBitmap = p.isAntiAlias          // піксельний режим — без згладжування
        c.drawBitmap(bmp, null, dstRect, spritePaint)
        c.restore()
    }

    // ---------- заєць ----------
    private fun rabbit(c: Canvas, p: Paint, a: AnimState) {
        val brown = 0xFFB9783E.toInt()
        val light = 0xFFF0D3A8.toInt()
        val hop = if (a.walk >= 0f) -abs(sin(a.walk * TWO_PI)) * 4f else 0f
        c.save()
        c.translate(0f, hop)
        ov(c, p, 2f, 29f, 11f, 38f, light)          // хвостик
        ov(c, p, 5f, 22f, 33f, 45f, brown)          // тіло
        fo(c, p, 13f, 33f, 29f, 44f, light)         // пузо
        ov(c, p, 7f, 39f, 20f, 46f, brown)          // задня лапа
        ov(c, p, 25f, 40f, 37f, 46f, brown)         // передня лапа
        ov(c, p, 25f, 4f, 31f, 19f, brown)          // вуха
        ov(c, p, 33f, 3f, 39f, 18f, brown)
        fo(c, p, 27f, 7f, 29f, 16f, PINK)
        fo(c, p, 35f, 6f, 37f, 15f, PINK)
        ov(c, p, 23f, 15f, 42f, 33f, brown)         // голова
        eye(c, p, 36.5f, 23f, 1.8f, a.eyeOpen)
        fo(c, p, 32f, 26f, 36f, 29.5f, 0x66FF8FA3)  // щічка
        dot(c, p, 41f, 26.5f, 1.4f, PINK)           // ніс
        if (a.eating > 0.1f) fo(c, p, 36f, 28.5f, 40f, 28.5f + 3.5f * a.eating, DARK)
        c.restore()
    }

    // ---------- краб ----------
    private fun crab(c: Canvas, p: Paint, a: AnimState) {
        val org = 0xFFE8663C.toInt()
        val lt = 0xFFF59B72.toInt()
        val w = if (a.walk >= 0f) a.walk * TWO_PI * 2f else a.t * 2f
        for (i in 0..2) {
            val dx = sin(w + i * 1.3f) * 1.6f
            val lx = 12f + i * 5f
            val rx = 36f - i * 5f
            line(c, p, lx, 40f, lx - 3f + dx, 46f, 1.6f, DARK)
            line(c, p, rx, 40f, rx + 3f - dx, 46f, 1.6f, DARK)
        }
        val up = if (a.scared) 6f else 0f
        val swL = sin(a.t * 5f) * 2f - up
        val swR = sin(a.t * 5f + 1.5f) * 2f - up
        line(c, p, 10f, 33f, 5f, 24f + swL, 2f, DARK)
        line(c, p, 38f, 33f, 43f, 24f + swR, 2f, DARK)
        ov(c, p, 0.5f, 15f + swL, 9.5f, 24f + swL, org)
        ov(c, p, 38.5f, 15f + swR, 47.5f, 24f + swR, org)
        tri(c, p, 3f, 15.2f + swL, 7f, 15.2f + swL, 5f, 19.5f + swL, DARK, false)
        tri(c, p, 41f, 15.2f + swR, 45f, 15.2f + swR, 43f, 19.5f + swR, DARK, false)
        ov(c, p, 8f, 26f, 40f, 43f, org)            // панцир
        fo(c, p, 14f, 28f, 24f, 32f, lt)
        line(c, p, 19f, 27f, 18f, 21f, 1.6f, DARK)  // очі на ніжках
        line(c, p, 29f, 27f, 30f, 21f, 1.6f, DARK)
        for (ex in floatArrayOf(18f, 30f)) {
            ov(c, p, ex - 3.4f, 15.6f, ex + 3.4f, 22.4f, Color.WHITE)
            if (a.eyeOpen < 0.3f) line(c, p, ex - 2.5f, 19f, ex + 2.5f, 19f, 1.3f, DARK)
            else dot(c, p, ex + 0.6f, 19.4f, 1.5f, DARK)
        }
        if (a.eating > 0.1f) {
            fo(c, p, 21.5f, 35.5f, 26.5f, 36.5f + 4f * a.eating, DARK)
        } else {
            line(c, p, 21f, 36.5f, 24f, 38f, 1.3f, DARK)
            line(c, p, 24f, 38f, 27f, 36.5f, 1.3f, DARK)
        }
    }

    // ---------- робот ----------
    private fun robot(c: Canvas, p: Paint, a: AnimState) {
        val blue = 0xFF4C6EF5.toInt()
        val dk = 0xFF2F44B5.toInt()
        val visor = 0xFF121A3A.toInt()
        val cyan = 0xFF7DF9FF.toInt()
        val s = if (a.walk >= 0f) sin(a.walk * TWO_PI) else 0f
        val liftL = max(0f, s) * 3.5f
        val liftR = max(0f, -s) * 3.5f
        rr(c, p, 14f, 40f - liftL, 22f, 46f - liftL, 2.5f, dk)
        rr(c, p, 26f, 40f - liftR, 34f, 46f - liftR, 2.5f, dk)
        ov(c, p, 4f, 23f, 11f, 31f, dk)
        ov(c, p, 37f, 23f, 44f, 31f, dk)
        rr(c, p, 8f, 12f, 40f, 42f, 10f, blue)
        rr(c, p, 12f, 14f, 22f, 16.5f, 1.2f, 0xFF8AA4FF.toInt(), false)
        rr(c, p, 12f, 19f, 36f, 35f, 6f, visor)
        val eh = if (a.scared) 9f else 7f * a.eyeOpen.coerceAtLeast(0.12f)
        p.style = Paint.Style.FILL; p.color = cyan
        c.drawRoundRect(17f, 27f - eh / 2f, 22f, 27f + eh / 2f, 2f, 2f, p)
        c.drawRoundRect(26f, 27f - eh / 2f, 31f, 27f + eh / 2f, 2f, 2f, p)
        if (a.eating > 0.1f) {
            p.color = cyan
            c.drawRect(21f, 31f, 27f, 31f + 2.5f * a.eating, p)
        }
        line(c, p, 24f, 12f, 24f, 6f, 1.6f, DARK)
        val blink = (a.t * 2f).toInt() % 2 == 0
        dot(c, p, 24f, 5f, 2.6f, if (blink) 0xFFFF5470.toInt() else 0xFFFFB3C0.toInt())
    }

    // ---------- кіт ----------
    private fun cat(c: Canvas, p: Paint, a: AnimState) {
        val org = 0xFFF2A65A.toInt()
        val stripe = 0xFFC97A2B.toInt()
        val wag = sin(a.t * 4f) * 3f
        // хвіст
        path.reset()
        path.moveTo(8f, 38f)
        path.quadTo(0f, 32f + wag, 4f, 20f + wag)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 5.2f; p.color = DARK
        c.drawPath(path, p)
        p.strokeWidth = 3f; p.color = org
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        // лапи
        val s = if (a.walk >= 0f) sin(a.walk * TWO_PI) else 0f
        val l1 = max(0f, s) * 2.5f
        val l2 = max(0f, -s) * 2.5f
        ov(c, p, 8f, 40f - l1, 15f, 46f - l1, org)
        ov(c, p, 17f, 40f - l2, 24f, 46f - l2, org)
        ov(c, p, 24f, 40f - l1, 31f, 46f - l1, org)
        ov(c, p, 31f, 40f - l2, 38f, 46f - l2, org)
        // тіло
        ov(c, p, 5f, 24f, 34f, 45f, org)
        line(c, p, 13f, 25.5f, 13f, 30f, 1.6f, stripe)
        line(c, p, 18f, 25f, 18f, 29.5f, 1.6f, stripe)
        line(c, p, 23f, 25.5f, 23f, 30f, 1.6f, stripe)
        // вуха
        tri(c, p, 24f, 19f, 26f, 6f, 32f, 14f, org, true)
        tri(c, p, 33f, 14f, 38.5f, 6f, 41f, 19f, org, true)
        tri(c, p, 26.5f, 15f, 27.2f, 9.5f, 30.5f, 14f, PINK, false)
        tri(c, p, 34.5f, 14f, 37.5f, 9.5f, 39.5f, 16f, PINK, false)
        // голова
        ov(c, p, 23f, 14f, 42f, 33f, org)
        line(c, p, 31f, 15f, 31f, 18.5f, 1.4f, stripe)
        line(c, p, 34f, 14.8f, 34f, 18f, 1.4f, stripe)
        eye(c, p, 36.5f, 23f, 1.8f, a.eyeOpen)
        dot(c, p, 41f, 26f, 1.3f, PINK)
        line(c, p, 40f, 27.5f, 46.5f, 26f, 1f, DARK)
        line(c, p, 40f, 28.5f, 46.5f, 30f, 1f, DARK)
        if (a.eating > 0.1f) fo(c, p, 36f, 29f, 40f, 29f + 3.5f * a.eating, DARK)
    }
}
