package com.example.deskpets

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Серце програми: показує улюбленців поверх усіх вікон і крутить "фізику".
 * Кожен улюбленець — окреме маленьке вікно-оверлей, тому дотики поза ним
 * проходять до застосунків під ним.
 */
class PetService : Service(), Choreographer.FrameCallback {

    companion object {
        const val ACTION_STOP = "com.example.deskpets.STOP"
        const val ACTION_FEED_ALL = "com.example.deskpets.FEED_ALL"
        private const val CHANNEL = "pets"
        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val pets = ArrayList<Pet>()
    private var effects: EffectsView? = null

    private var started = false
    private var lastFrame = 0L
    private var density = 1f
    private var touchSlop = 8
    private var screenW = 1080
    private var screenH = 1920
    private var sizePx = 200
    private var floorPx = 0
    private var effectsWasActive = false

    private val g: Float get() = 2200f * density

    private val applyRunnable = Runnable { applySettings() }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.removeCallbacks(applyRunnable)
        handler.postDelayed(applyRunnable, 120)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        density = resources.displayMetrics.density
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Улюбленці на екрані", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!started) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            started = true
            running = true
            refreshScreen()
            addEffects()
            applySettings()
            prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
            lastFrame = 0L
            Choreographer.getInstance().postFrameCallback(this)
        }
        if (intent?.action == ACTION_FEED_ALL) {
            pets.toList().forEach { feed(it) }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.postDelayed({ refreshScreen() }, 300)
    }

    override fun onDestroy() {
        started = false
        running = false
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(this)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        pets.toList().forEach { removePet(it) }
        effects?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        effects = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ сповіщення

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val feed = PendingIntent.getService(
            this, 2, Intent(this, PetService::class.java).setAction(ACTION_FEED_ALL),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, PetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Улюбленці на екрані")
            .setContentText("Подвійний тап по улюбленцю — нагодувати")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "Нагодувати всіх", feed).build())
            .addAction(Notification.Action.Builder(icon, "Зупинити", stop).build())
            .build()
    }

    // ------------------------------------------------------------ екран і вікна

    private fun refreshScreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width()
            screenH = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels
            screenH = dm.heightPixels
        }
    }

    private fun addEffects() {
        val ev = EffectsView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Android 12+ блокує дотики крізь повністю непрозорі оверлеї, тому alpha < 0.8
        lp.alpha = 0.79f
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        ev.pets = pets
        wm.addView(ev, lp)
        effects = ev
    }

    private fun addPet(type: Int) {
        val view = PetView(this, type)
        val lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val pet = Pet(type, view, lp)
        pet.x = Random.nextFloat() * max(1, screenW - sizePx)
        pet.y = -sizePx.toFloat()           // нові улюбленці падають зверху
        pet.state = State.FALL
        pet.dir = if (Random.nextBoolean()) 1 else -1
        lp.x = pet.x.toInt()
        lp.y = pet.y.toInt()
        view.pixel = prefs.pixel

        pet.detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                tap(pet); return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                feed(pet); return true
            }
        }).also { it.setIsLongpressEnabled(false) }

        view.setOnTouchListener { _, e -> onPetTouch(pet, e) }
        wm.addView(view, lp)
        pets.add(pet)
    }

    private fun removePet(p: Pet) {
        try { wm.removeView(p.view) } catch (e: Exception) { }
        p.tracker?.recycle()
        p.tracker = null
        pets.remove(p)
    }

    private fun sync(p: Pet, force: Boolean = false) {
        val nx = p.x.toInt()
        val ny = p.y.toInt()
        if (!force && p.lp.x == nx && p.lp.y == ny) return
        p.lp.x = nx
        p.lp.y = ny
        try { wm.updateViewLayout(p.view, p.lp) } catch (e: Exception) { }
    }

    /** Застосовує налаштування: кількість, розмір, види, стиль. Викликається наживо. */
    private fun applySettings() {
        if (!started) return
        refreshScreen()
        sizePx = (prefs.sizeDp * density).toInt().coerceAtLeast(24)
        floorPx = (prefs.floorDp * density).toInt()

        val enabled = (0 until Phrases.TYPE_COUNT)
            .filter { prefs.types and (1 shl it) != 0 }
            .ifEmpty { listOf(0) }

        pets.filter { it.type !in enabled }.forEach { removePet(it) }
        while (pets.size > prefs.count) removePet(pets.last())
        while (pets.size < prefs.count) {
            // беремо випадковий вид серед найменш представлених — щоб були всі різні
            val least = enabled.minOf { ty -> pets.count { it.type == ty } }
            addPet(enabled.filter { ty -> pets.count { it.type == ty } == least }.random())
        }

        val maxX = (screenW - sizePx).toFloat().coerceAtLeast(0f)
        val maxY = (screenH - sizePx).toFloat().coerceAtLeast(0f)
        for (p in pets) {
            p.lp.width = sizePx
            p.lp.height = sizePx
            p.view.pixel = prefs.pixel
            p.x = p.x.coerceIn(0f, maxX)
            p.y = p.y.coerceIn(-sizePx.toFloat(), maxY)
            sync(p, force = true)
            p.view.invalidate()
        }
    }

    // ------------------------------------------------------------ дотики

    private fun track(p: Pet, e: MotionEvent) {
        val copy = MotionEvent.obtain(e)
        copy.setLocation(e.rawX, e.rawY)   // вікно їде разом із пальцем, тому беремо "сирі" координати
        p.tracker?.addMovement(copy)
        copy.recycle()
    }

    private fun onPetTouch(p: Pet, e: MotionEvent): Boolean {
        p.detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                p.downX = e.rawX
                p.downY = e.rawY
                p.dragging = false
                p.tracker?.recycle()
                p.tracker = VelocityTracker.obtain()
                track(p, e)
            }
            MotionEvent.ACTION_MOVE -> {
                track(p, e)
                if (!p.dragging &&
                    hypot(e.rawX - p.downX, e.rawY - p.downY) > touchSlop * 1.5f
                ) {
                    p.dragging = true
                    p.grabDx = e.rawX - p.x
                    p.grabDy = e.rawY - p.y
                    startDrag(p)
                }
                if (p.dragging) {
                    val maxX = (screenW - sizePx).toFloat().coerceAtLeast(0f)
                    val maxY = (screenH - sizePx).toFloat().coerceAtLeast(0f)
                    p.x = (e.rawX - p.grabDx).coerceIn(0f, maxX)
                    p.y = (e.rawY - p.grabDy).coerceIn(0f, maxY)
                    sync(p)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                track(p, e)
                if (p.dragging) {
                    p.tracker?.computeCurrentVelocity(1000)
                    release(p, p.tracker?.xVelocity ?: 0f, p.tracker?.yVelocity ?: 0f)
                }
                p.tracker?.recycle()
                p.tracker = null
                p.dragging = false
            }
        }
        return true
    }

    private fun startDrag(p: Pet) {
        p.state = State.DRAG
        p.vx = 0f
        p.vy = 0f
        say(p, Phrases.scared.random(), 1.6f)
    }

    private fun release(p: Pet, vx: Float, vy: Float) {
        p.vx = vx.coerceIn(-8000f, 8000f)
        p.vy = vy.coerceIn(-8000f, 8000f)
        if (abs(p.vx) > 50f) p.dir = if (p.vx > 0) 1 else -1
        p.state = State.FALL
    }

    // ------------------------------------------------------------ дії

    private fun say(p: Pet, text: String, secs: Float = 2.5f) {
        p.bubble = text
        p.bubbleT = secs
    }

    private fun jump(p: Pet, heightFactor: Float) {
        p.state = State.FALL
        p.vy = -sqrt(2f * g * sizePx * heightFactor)
        p.vx = 0f
    }

    private fun tap(p: Pet) {
        if (p.state == State.DRAG || p.state == State.EAT) return
        say(p, if (p.state == State.SLEEP) Phrases.wake.random() else Phrases.tap.random(), 1.8f)
        jump(p, 0.5f)
    }

    private fun feed(p: Pet) {
        if (p.state == State.DRAG || p.state == State.FALL) return
        if (p.fullness > 5.2f) {
            say(p, Phrases.full.random(), 2f)
            return
        }
        p.fullness += 1f
        p.state = State.EAT
        p.timer = 1.8f
        p.vx = 0f
        say(p, Phrases.yum.random(), 2f)
        val mouthX = if (p.type == PetArt.CRAB || PetArt.isLogo(p.type)) p.cx else p.cx + p.dir * sizePx * 0.2f
        effects?.add(
            Particle(
                Phrases.food[p.type], mouthX, p.y - sizePx * 0.7f, 0f, 0f, 3f,
                sizePx * 0.35f, 1600f * density, Color.WHITE, p.y + sizePx * 0.3f
            )
        )
    }

    private fun finishEat(p: Pet) {
        p.state = State.IDLE
        p.timer = 0.6f
        val ev = effects ?: return
        repeat(4) {
            ev.add(
                Particle(
                    "❤️",
                    p.cx + (Random.nextFloat() - 0.5f) * sizePx * 0.6f,
                    p.y + sizePx * 0.1f,
                    (Random.nextFloat() - 0.5f) * 60f * density,
                    -(90f + Random.nextFloat() * 60f) * density,
                    1.4f, (13f + Random.nextFloat() * 8f) * density, 0f
                )
            )
        }
    }

    private fun dust(p: Pet) {
        val ev = effects ?: return
        repeat(5) {
            ev.add(
                Particle(
                    "", p.cx + (Random.nextFloat() - 0.5f) * sizePx * 0.5f, p.y + sizePx * 0.95f,
                    (Random.nextFloat() - 0.5f) * 160f * density,
                    -(40f + Random.nextFloat() * 60f) * density,
                    0.5f, (2f + Random.nextFloat() * 2f) * density, 400f * density,
                    0xCCFFFFFF.toInt(), Float.MAX_VALUE, 1
                )
            )
        }
    }

    private fun pickNext(p: Pet) {
        val r = Random.nextFloat()
        when {
            r < 0.55f -> {
                p.state = State.WALK
                p.dir = if (Random.nextBoolean()) 1 else -1
                p.timer = 2f + Random.nextFloat() * 5f
            }
            r < 0.80f -> {
                p.state = State.IDLE
                p.timer = 1f + Random.nextFloat() * 2.5f
            }
            r < 0.92f -> {
                p.state = State.SLEEP
                p.timer = 6f + Random.nextFloat() * 8f
            }
            else -> jump(p, 0.6f)
        }
    }

    // ------------------------------------------------------------ головний цикл

    override fun doFrame(frameTimeNanos: Long) {
        if (!started) return
        val dt = if (lastFrame == 0L) 0.016f
        else ((frameTimeNanos - lastFrame) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastFrame = frameTimeNanos
        update(dt)
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun update(dt: Float) {
        val floorY = (screenH - floorPx - sizePx).toFloat()
        val maxX = (screenW - sizePx).toFloat().coerceAtLeast(0f)
        val speed = prefs.speed
        val walkSpeed = (12f + 11f * speed) * density
        val chatter = prefs.chatter

        for (p in pets) {
            p.t += dt
            p.fullness = (p.fullness - 0.12f * dt).coerceAtLeast(0f)
            if (p.bubbleT > 0f) {
                p.bubbleT -= dt
                if (p.bubbleT <= 0f) p.bubble = null
            }
            var moved = false
            var redraw = false

            // стоячі улюбленці завжди на "підлозі"
            if (p.state != State.DRAG && p.state != State.FALL) {
                if (p.x > maxX) { p.x = maxX; moved = true }
                if (p.y < floorY - 2f) {
                    p.state = State.FALL; p.vy = 0f; p.vx = 0f
                } else if (p.y != floorY) {
                    p.y = floorY; moved = true
                }
            }

            when (p.state) {
                State.DRAG -> redraw = true
                State.FALL -> {
                    p.vy += g * dt
                    p.x += p.vx * dt
                    p.y += p.vy * dt
                    if (p.x < 0f) { p.x = 0f; p.vx = -p.vx * 0.6f }
                    else if (p.x > maxX) { p.x = maxX; p.vx = -p.vx * 0.6f }
                    if (p.y < 0f && p.vy < 0f) { p.y = 0f; p.vy = -p.vy * 0.4f }
                    if (p.y >= floorY) {
                        p.y = floorY
                        val impact = abs(p.vy)
                        if (impact > 700f * density) {
                            p.vy = -p.vy * 0.42f
                            p.vx *= 0.75f
                            if (impact > 1500f * density) {
                                dust(p)
                                if (Random.nextFloat() < 0.5f) say(p, Phrases.ouch.random(), 1.5f)
                            }
                        } else {
                            p.vy = 0f
                            p.vx -= p.vx * minOf(1f, 5f * dt)   // ковзає й гальмує
                            if (abs(p.vx) < 30f * density) {
                                p.vx = 0f
                                p.state = State.IDLE
                                p.timer = 0.4f + Random.nextFloat()
                            }
                        }
                    }
                    moved = true; redraw = true
                }
                State.IDLE -> {
                    p.timer -= dt
                    if (p.timer <= 0f) pickNext(p)
                }
                State.WALK -> {
                    p.x += p.dir * walkSpeed * dt
                    if (p.x <= 0f) { p.x = 0f; p.dir = 1 }
                    else if (p.x >= maxX) { p.x = maxX; p.dir = -1 }
                    p.walkPhase += dt * (1.5f + speed * 0.35f)
                    p.timer -= dt
                    if (p.timer <= 0f) pickNext(p)
                    moved = true; redraw = true
                }
                State.SLEEP -> {
                    p.timer -= dt
                    if (p.timer <= 0f) { p.state = State.IDLE; p.timer = 1f }
                }
                State.EAT -> {
                    p.timer -= dt
                    redraw = true
                    if (p.timer <= 0f) finishEat(p)
                }
            }

            // випадкові репліки
            if (chatter && p.bubble == null &&
                (p.state == State.IDLE || p.state == State.WALK) &&
                Random.nextFloat() < 0.03f * dt
            ) {
                say(p, Phrases.chat(p.type), 2.8f)
            }

            // анімація
            val a = p.view.anim
            a.t = p.t
            a.dir = p.dir
            a.sleeping = p.state == State.SLEEP
            a.scared = p.state == State.DRAG
            a.eating = if (p.state == State.EAT) abs(sin(p.t * 14f)) else 0f
            a.walk = when (p.state) {
                State.WALK -> p.walkPhase % 1f
                State.DRAG -> (p.t * 4f) % 1f
                else -> -1f
            }
            p.blinkT -= dt
            val eyes = if (a.sleeping || p.blinkT < 0.12f) 0f else 1f
            if (p.blinkT <= 0f) p.blinkT = 2f + Random.nextFloat() * 3f
            if (eyes != a.eyeOpen) { a.eyeOpen = eyes; redraw = true }
            if (p.state != p.lastState) { p.lastState = p.state; redraw = true }

            if (moved) sync(p)
            if (redraw) p.view.invalidate()
        }

        val ev = effects
        if (ev != null) {
            ev.step(dt)
            val active = ev.hasContent()
            if (active || effectsWasActive) ev.invalidate()
            effectsWasActive = active
        }
    }
}
