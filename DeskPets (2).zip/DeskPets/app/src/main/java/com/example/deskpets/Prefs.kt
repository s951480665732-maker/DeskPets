package com.example.deskpets

import android.content.Context
import android.content.SharedPreferences

/** Усі налаштування застосунку. Сервіс слухає зміни й оновлюється "наживо". */
class Prefs(context: Context) {
    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("deskpets", Context.MODE_PRIVATE)

    /** Скільки улюбленців на екрані */
    var count: Int
        get() = sp.getInt("count", 5)
        set(v) = sp.edit().putInt("count", v).apply()

    /** Розмір улюбленця, dp */
    var sizeDp: Int
        get() = sp.getInt("size", 72)
        set(v) = sp.edit().putInt("size", v).apply()

    /** Швидкість ходьби 1..10 */
    var speed: Int
        get() = sp.getInt("speed", 4)
        set(v) = sp.edit().putInt("speed", v).apply()

    /** Відступ "підлоги" від низу екрана, dp */
    var floorDp: Int
        get() = sp.getInt("floor", 24)
        set(v) = sp.edit().putInt("floor", v).apply()

    /** Чи говорять улюбленці самі по собі */
    var chatter: Boolean
        get() = sp.getBoolean("chatter", true)
        set(v) = sp.edit().putBoolean("chatter", v).apply()

    /** Піксельний стиль (як на відео) чи гладкий */
    var pixel: Boolean
        get() = sp.getBoolean("pixel", true)
        set(v) = sp.edit().putBoolean("pixel", v).apply()

    /** Бітова маска увімкнених видів (біт = номер виду; за замовчуванням усі 9) */
    var types: Int
        get() = sp.getInt("types_v2", 511)
        set(v) = sp.edit().putInt("types_v2", v).apply()
}
