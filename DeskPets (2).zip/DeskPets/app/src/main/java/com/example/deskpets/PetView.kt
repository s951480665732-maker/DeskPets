package com.example.deskpets

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Вікно одного улюбленця. Малює його сам; рухом і дотиками керує PetService. */
class PetView(ctx: Context, val type: Int) : View(ctx) {
    val anim = AnimState()
    var pixel = true

    private val paint = Paint()

    // для іконок-улюбленців: велика картинка (гладкий режим) і маленька 36x36 (піксельний)
    private val hi: Bitmap? = PetArt.spriteRes(type).let {
        if (it != 0) BitmapFactory.decodeResource(ctx.resources, it) else null
    }
    private val lo: Bitmap? = hi?.let { Bitmap.createScaledBitmap(it, 36, 36, true) }
    private val bmp: Bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
    private val bmpCanvas = Canvas(bmp)
    private val dst = RectF()
    private val bmpPaint = Paint().apply {
        isFilterBitmap = false
        isAntiAlias = false
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (pixel) {
            bmp.eraseColor(Color.TRANSPARENT)
            paint.isAntiAlias = false
            PetArt.draw(bmpCanvas, type, anim, paint, lo)
            dst.set(0f, 0f, w, h)
            c.drawBitmap(bmp, null, dst, bmpPaint)
        } else {
            paint.isAntiAlias = true
            c.save()
            c.scale(w / 48f, h / 48f)
            PetArt.draw(c, type, anim, paint, hi)
            c.restore()
        }
    }
}
