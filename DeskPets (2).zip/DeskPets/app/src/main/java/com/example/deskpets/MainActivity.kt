package com.example.deskpets

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Екран налаштувань: запуск/зупинка, кількість, розмір, швидкість, види. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var toggleBtn: Button
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        scroll.addView(col)
        setContentView(scroll)

        col.addView(TextView(this).apply {
            text = "Desktop Pets"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        col.addView(TextView(this).apply {
            text = "Маленькі улюбленці бігають поверх усіх вікон.\n" +
                "• тап — підстрибне\n" +
                "• подвійний тап — нагодувати\n" +
                "• потягни й відпусти — кинути"
            textSize = 15f
            setPadding(0, dp(8), 0, dp(8))
        })

        statusView = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(4))
        }
        col.addView(statusView)

        toggleBtn = Button(this).apply { setOnClickListener { onToggle() } }
        col.addView(toggleBtn)

        col.addView(Button(this).apply {
            text = "Нагодувати всіх 🍎"
            setOnClickListener {
                if (PetService.running) {
                    startService(
                        Intent(this@MainActivity, PetService::class.java)
                            .setAction(PetService.ACTION_FEED_ALL)
                    )
                } else {
                    Toast.makeText(this@MainActivity, "Спершу запустіть улюбленців", Toast.LENGTH_SHORT).show()
                }
            }
        })

        addTitle(col, "Налаштування")
        addSlider(col, "Скільки улюбленців", 1, 15, prefs.count, "") { prefs.count = it }
        addSlider(col, "Розмір", 32, 220, prefs.sizeDp, " dp") { prefs.sizeDp = it }
        addSlider(col, "Швидкість", 1, 10, prefs.speed, "") { prefs.speed = it }
        addSlider(col, "Висота «підлоги» від низу", 0, 200, prefs.floorDp, " dp") { prefs.floorDp = it }

        col.addView(Switch(this).apply {
            text = "Говорять самі по собі"
            isChecked = prefs.chatter
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, checked -> prefs.chatter = checked }
        })
        col.addView(Switch(this).apply {
            text = "Піксельний стиль"
            isChecked = prefs.pixel
            setPadding(0, dp(12), 0, 0)
            setOnCheckedChangeListener { _, checked -> prefs.pixel = checked }
        })

        addTitle(col, "Хто живе на екрані")
        for (i in 0 until Phrases.TYPE_COUNT) {
            col.addView(CheckBox(this).apply {
                text = Phrases.typeNames[i]
                isChecked = prefs.types and (1 shl i) != 0
                setOnCheckedChangeListener { buttonView, checked ->
                    val m = if (checked) prefs.types or (1 shl i) else prefs.types and (1 shl i).inv()
                    if (m == 0) buttonView.isChecked = true   // хоч один має лишитися
                    else prefs.types = m
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val running = PetService.running
        val canDraw = Settings.canDrawOverlays(this)
        statusView.text = when {
            running -> "Статус: улюбленці на екрані ✅"
            !canDraw -> "Статус: потрібен дозвіл «Поверх інших вікон»"
            else -> "Статус: зупинено"
        }
        toggleBtn.text = if (running) "Зупинити улюбленців" else "Запустити улюбленців"
    }

    private fun onToggle() {
        if (PetService.running) {
            stopService(Intent(this, PetService::class.java))
            handler.postDelayed({ refresh() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Дозвольте показ поверх інших вікон і поверніться назад", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, PetService::class.java))
        handler.postDelayed({ refresh() }, 400)
    }

    private fun addTitle(col: LinearLayout, text: String) {
        col.addView(TextView(this).apply {
            this.text = text
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.START
            setPadding(0, dp(28), 0, 0)
        })
    }

    private fun addSlider(
        col: LinearLayout, title: String, lo: Int, hi: Int, value: Int, unit: String,
        onChange: (Int) -> Unit
    ) {
        val label = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(16), 0, 0)
        }
        fun upd(v: Int) { label.text = "$title: $v$unit" }
        upd(value)
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = (value - lo).coerceIn(0, hi - lo)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                upd(v)
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        col.addView(label)
        col.addView(bar)
    }
}
