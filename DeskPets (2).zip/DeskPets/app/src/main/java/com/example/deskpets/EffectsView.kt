package com.example.deskpets

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** kind 0 = емодзі/текст, kind 1 = кружечок (пил) */
class Particle(
    val text: String,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var life: Float,
    val size: Float,
    val gravity: Float,
    val color: Int = Color.WHITE,
    val targetY: Float = Float.MAX_VALUE,
    val kind: Int = 0
)

/**
 * Один прозорий екран поверх усього (не ловить дотики): малює репліки в бульбашках,
 * "z-z-z" для сплячих, їжу, що падає, серденька та пил від приземлення.
 */
class EffectsView(ctx: Context) : View(ctx) {
    var pets: List<Pet> = emptyList()
    private val particles = ArrayList<Particle>()
    private val d = resources.displayMetrics.density
    private val rect = RectF()

    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE62B2B2B.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * d
        typeface = Typeface.DEFAULT
    }
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
    }
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun add(p: Particle) { particles.add(p) }

    fun step(dt: Float) {
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.vy += p.gravity * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            if (p.life <= 0f || p.y >= p.targetY) it.remove()
        }
    }

    fun hasContent(): Boolean =
        particles.isNotEmpty() || pets.any { it.bubble != null || it.state == State.SLEEP }

    override fun onDraw(c: Canvas) {
        for (p in pets) {
            val b = p.bubble
            if (b != null) drawBubble(c, p, b)
            if (p.state == State.SLEEP) drawZ(c, p)
        }
        for (pt in particles) {
            val alpha = (minOf(1f, pt.life / 0.4f) * 255).toInt().coerceIn(0, 255)
            if (pt.kind == 0) {
                emojiPaint.textSize = pt.size
                emojiPaint.alpha = alpha
                c.drawText(pt.text, pt.x, pt.y, emojiPaint)
            } else {
                dotPaint.color = pt.color
                dotPaint.alpha = alpha
                c.drawCircle(pt.x, pt.y, pt.size, dotPaint)
            }
        }
    }

    private fun drawBubble(c: Canvas, p: Pet, text: String) {
        val padH = 8f * d
        val padV = 5f * d
        val fm = textPaint.fontMetrics
        val tw = textPaint.measureText(text)
        val bw = tw + padH * 2
        val bh = (fm.descent - fm.ascent) + padV * 2
        val left = (p.cx - bw / 2f).coerceIn(4f * d, maxOf(4f * d, width - bw - 4f * d))
        var top = p.y - bh - 4f * d
        if (top < 4f * d) top = p.y + p.lp.height + 4f * d
        rect.set(left, top, left + bw, top + bh)
        c.drawRoundRect(rect, 10f * d, 10f * d, bubblePaint)
        c.drawText(text, left + padH, top + padV - fm.ascent, textPaint)
    }

    private fun drawZ(c: Canvas, p: Pet) {
        val size = p.lp.width.toFloat()
        val ph = (p.t % 2f) / 2f
        zPaint.textSize = (12f + ph * 8f) * d
        zPaint.alpha = ((1f - ph) * 255).toInt().coerceIn(0, 255)
        c.drawText("z", p.cx + size * 0.15f + ph * size * 0.3f, p.y + size * 0.3f - ph * size * 0.5f, zPaint)
    }
}
